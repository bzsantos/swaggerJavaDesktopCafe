package fatec.dsm;


public class Carro extends Auto {
    private double valor;
    private boolean disponibilidade;

    public Carro(String marca) {
        super(marca);
    }
    
    
    
    
    
    
    
    
    
    //Getters & Setters

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public boolean isDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(boolean disponibilidade) {
        this.disponibilidade = disponibilidade;
    }
    
    
    
}
