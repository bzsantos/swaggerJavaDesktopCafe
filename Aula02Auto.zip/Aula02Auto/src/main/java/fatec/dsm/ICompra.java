package fatec.dsm;

public interface ICompra {
    
    public abstract void cadastrousuario();
    public abstract double compra();
    
}
