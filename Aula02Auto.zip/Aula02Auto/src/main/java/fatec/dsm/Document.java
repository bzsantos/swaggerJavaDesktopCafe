package fatec.dsm;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info; // <-- O IMPORT CORRETO É ESSE AQUI!
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration; // Adicionado para o Spring reconhecer a classe

@Configuration // Adicione isso para o Spring Boot saber que deve ler este arquivo
public class Document {
    
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info() // Agora ele vai reconhecer o Info do Swagger
                .title("API Local do meu App Desktop")
                .version("1.0.0")
                .description("Esta API roda localmente na máquina do usuário."));
    }
    
}