package fatec.dsm;

public class Cliente extends Carro implements ICompra {
    private String nomecli;
    private String cpf;

    public Cliente(String marca) {
        super(marca);
    }
    
     public void cadastrousuario() {
         this.setNomecli("Ronald");
         this.setCpf("222555446-96");      
        
         System.out.println("O nome é: " + this.getNomecli() + "\n Seu CPF: " + this.getCpf());
         
        
    }

    @Override
    public double compra() {
        this.setValor(254.000);
        return this.getValor();
    }

    
    
    
    
    //Getters e Setters

    public String getNomecli() {
        return nomecli;
    }

    public void setNomecli(String nomecli) {
        this.nomecli = nomecli;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}


    
    
    

